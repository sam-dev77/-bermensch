import React from 'react';
import DashboardAnalytics from '../components/DashboardAnalytics';

const SuperAdmin: React.FC = () => {
  return (
    <>
      <DashboardAnalytics />
      {/* Add Manage Institutions, Audit Log UI here */}
    </>
  );
};

export default SuperAdmin;